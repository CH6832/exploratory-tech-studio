# Clock, Temperature and Time

## :newspaper: About the project

This Arduino script interfaces with a DHT11 sensor and an LCD display to create a clock-like device. It allows users to set the time using push buttons and displays both the current time and temperature/humidity readings on the LCD screen. The script initializes the hardware, continuously updates the time and sensor readings in the main loop, and implements methods for setting the hour and minute values with button input.
### How it works

1. Install the [Arduino IDE](https://www.arduino.cc/en/software)

2. Download the project from Github.

3. Open the .ino file in the IDE.

4. Plug in your [Arduino Uno Board](https://docs.arduino.cc/).

5. `Verify` and `Upload` the code.

### Content overview

    .
    ├── DHT.cpp/ - source code for the DHT-sensor
    ├── DHT.h/ - header file for the DHT.cpp
    ├── Digiuhr_Temp_Feucht.ino/ - source code
    ├── LICENSE - license text
    └── README.md - relevant information about the project

## :books: Resources used to create this project

* Arduino
  * [Arduino IDE](https://www.arduino.cc/en/software)
  * [Language Reference](https://www.arduino.cc/reference/en/)
* C
  * [C language](https://en.cppreference.com/w/c/language)
* Markdwon
  * [Basic syntax](https://www.markdownguide.org/basic-syntax/)
  * [Complete list of github markdown emofis](https://dev.to/nikolab/complete-list-of-github-markdown-emoji-markup-5aia)
  * [Awesome template](http://github.com/Human-Activity-Recognition/blob/main/README.md)
  * [.gitignore file](https://git-scm.com/docs/gitignore)
* Editor
  * [Visual Studio Code](https://code.visualstudio.com/)
 
## :bookmark: License

This project is licensed under the terms of the [Creative Common Share-Alike License 3.0](LICENSE).
